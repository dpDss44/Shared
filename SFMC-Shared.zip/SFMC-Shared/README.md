# SFMC - Shared
This branch is for sharing the portfolio/examples of code only.
